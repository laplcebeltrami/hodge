function hodge_display(S, Base, ngrid)
% HODGE_DISPLAY  Single-row (Edge Flow, Gradient, Curl, Harmonic) visualization.
%
% Inputs:
%   S.P      : nV x 2 vertex coordinates
%   S.E      : mE x 2 undirected edges with u < v (defines edge orientation)
%   S.T      : nF x 3 triangle indices (CCW)
%   Base   : Edge flow defined on directed edge E
%   ngrid  : grid resolution
%
% Usage:
%   out = hodge_display(P, T, E, Base)          % per-face quiver (no interpolation)
%   out = hodge_display(P, T, E, Base, ngrid)   % if ngrid>0: interpolate & streamlines
%
% Note: Streamline color encodes the magnitude of the plotted vector field 
% for the chosen Hodge component(Edge/Grad/Curl/Harmonic). For each component 
% we form S = hypot(U, V), which equals |v| = sqrt(U.^2 + V.^2) on the interpolation grid. 
%
%
% (C) 2025 Moo K. Chung 
% mkchung@wisc.edu
% University of Wisconsin-Madison

P=S.P;
E=S.E;
T=S.T;

% ---------- Build incidences ----------
[nV,~] = size(P); mE = size(E,1); nF = size(T,1);

% B1: node-edge incidence (u->v for u<v)
tails = E(:,1); heads = E(:,2);
B1 = sparse(nV,mE);
B1 = B1 + sparse(tails,(1:mE)',-1,nV,mE) + sparse(heads,(1:mE)',+1,nV,mE);

% B2: edge-face incidence, consistent with CCW T
B2 = sparse(mE,nF);
for f = 1:nF
    v1 = T(f,1); v2 = T(f,2); v3 = T(f,3);
    [e12,s12] = edge_index_sign(v1,v2,E);
    [e23,s23] = edge_index_sign(v2,v3,E);
    [e31,s31] = edge_index_sign(v3,v1,E);
    if e12>0, B2(e12,f) = B2(e12,f) + s12; end
    if e23>0, B2(e23,f) = B2(e23,f) + s23; end
    if e31>0, B2(e31,f) = B2(e31,f) + s31; end
end

% ---------- Projectors ----------
PG = B1' * pinv(full(B1*B1')) * B1;   % gradient
PC = B2  * pinv(full(B2'*B2)) * B2';  % curl
PH = speye(mE) - PG - PC;             % harmonic

% ---------- Pull & validate flows ----------
F = ensure_components_and_validate(Base, PG, PC, PH, mE);

% ---------- Face-level vector fields (used in both modes) ----------
[CX, CY, Ux, Vx] = edgeflow_to_facevec(P, T, E, F.X);
[~,  ~, Ug, Vg]  = edgeflow_to_facevec(P, T, E, F.G);
[~,  ~, Uc, Vc]  = edgeflow_to_facevec(P, T, E, F.C);
[~,  ~, Uh, Vh]  = edgeflow_to_facevec(P, T, E, F.H);

% Magnitudes on faces
MX = hypot(Ux,Vx); MG = hypot(Ug,Vg); MC = hypot(Uc,Vc); MH = hypot(Uh,Vh);

% Colormaps
cmapGray  = single_hue_map([0.96 0.96 0.96],[0.35 0.35 0.35],256);
cmapBlue  = single_hue_map([0.75 0.90 1.00],[0.00 0.35 1.00],256);
cmapGreen = single_hue_map([0.80 0.95 0.80],[0.10 0.55 0.10],256);
cmapRed   = single_hue_map([0.98 0.85 0.85],[0.80 0.20 0.20],256);

% Mode & bbox
xlo = min(P(:,1)); xhi = max(P(:,1));
ylo = min(P(:,2)); yhi = max(P(:,2));

% ---------- Plot (single row, 4 columns) ----------
figure('Color','w','Position',[60 60 1280 340]);
tiledlayout(1,4,'Padding','compact','TileSpacing','compact');
fmt      = @(ax) set(ax,'DataAspectRatio',[1 1 1],'FontSize',20);
titlefmt = @(ax,str) title(ax,str,'FontSize',20,'FontWeight','bold');

% INTERPOLATION: grid + streamlines over rectangular bbox
seed_step = 1; stream_lw = 3;

[Xg, Yg, X_U, X_V] = facevec_to_grid_rect(CX, CY, Ux, Vx, ngrid, [xlo xhi ylo yhi]);
[~,  ~,  G_U, G_V] = facevec_to_grid_rect(CX, CY, Ug, Vg, ngrid, [xlo xhi ylo yhi]);
[~,  ~,  C_U, C_V] = facevec_to_grid_rect(CX, CY, Uc, Vc, ngrid, [xlo xhi ylo yhi]);
[~,  ~,  H_U, H_V] = facevec_to_grid_rect(CX, CY, Uh, Vh, ngrid, [xlo xhi ylo yhi]);

MAG_X = hypot(X_U,X_V); X_lim = robust_clim(MAG_X);
MAG_G = hypot(G_U,G_V); G_lim = robust_clim(MAG_G);
MAG_C = hypot(C_U,C_V); C_lim = robust_clim(MAG_C);
MAG_H = hypot(H_U,H_V); H_lim = robust_clim(MAG_H);

% Edge Flow
nexttile; ax=gca; hold on; axis(ax,'equal'); axis(ax,'tight'); axis(ax,'off'); fmt(ax); xlim([xlo xhi]); ylim([ylo yhi]); titlefmt(ax,'Edge Flow');
streams_color_by_scalar_ax(ax, Xg,Yg, X_U,X_V, MAG_X, seed_step, stream_lw, cmapGray,  '||Edge||', X_lim);
draw_quiver_black(ax, Xg, Yg, X_U, X_V);

% Gradient
nexttile; ax=gca; hold on; axis(ax,'equal'); axis(ax,'tight'); axis(ax,'off'); fmt(ax); xlim([xlo xhi]); ylim([ylo yhi]); titlefmt(ax,'Gradient');
streams_color_by_scalar_ax(ax, Xg,Yg, G_U,G_V, MAG_G, seed_step, stream_lw, cmapBlue,  '||Grad||', G_lim);
draw_quiver_black(ax, Xg, Yg, G_U, G_V);

% Curl
nexttile; ax=gca; hold on; axis(ax,'equal'); axis(ax,'tight'); axis(ax,'off'); fmt(ax); xlim([xlo xhi]); ylim([ylo yhi]); titlefmt(ax,'Curl');
streams_color_by_scalar_ax(ax, Xg,Yg, C_U,C_V, MAG_C, seed_step, stream_lw, cmapGreen, '||Curl||', C_lim);
draw_quiver_black(ax, Xg, Yg, C_U, C_V);

% Harmonic
nexttile; ax=gca; hold on; axis(ax,'equal'); axis(ax,'tight'); axis(ax,'off'); fmt(ax); xlim([xlo xhi]); ylim([ylo yhi]); titlefmt(ax,'Harmonic');
streams_color_by_scalar_ax(ax, Xg,Yg, H_U,H_V, MAG_H, seed_step, stream_lw, cmapRed,   '||Harm||', H_lim);
draw_quiver_black(ax, Xg, Yg, H_U, H_V);

out = struct();
out.mode  = 'grid';
out.grid  = struct('Xg',Xg,'Yg',Yg,'X_U',X_U,'X_V',X_V,'G_U',G_U,'G_V',G_V,'C_U',C_U,'C_V',C_V,'H_U',H_U,'H_V',H_V);
out.lims  = struct('X',X_lim,'G',G_lim,'C',C_lim,'H',H_lim);
out.cmaps = struct('gray',cmapGray,'blue',cmapBlue,'green',cmapGreen,'red',cmapRed);

end

% ====================== Helpers ======================

function F = ensure_components_and_validate(Base, PG, PC, PH, mE)
F = struct();
hasX = isfield(Base,'X') && ~isempty(Base.X);
hasG = isfield(Base,'G') && ~isempty(Base.G);
hasC = isfield(Base,'C') && ~isempty(Base.C);
hasH = isfield(Base,'H') && ~isempty(Base.H);
if ~hasX && ~(hasG && hasC && hasH)
    error('Provide Base.X or all of Base.G/Base.C/Base.H.');
end
if ~hasX, F.X = Base.G(:)+Base.C(:)+Base.H(:); else, F.X = Base.X(:); end
if hasG, F.G = Base.G(:); else, F.G = PG*F.X; end
if hasC, F.C = Base.C(:); else, F.C = PC*F.X; end
if hasH, F.H = Base.H(:); else, F.H = PH*F.X; end
for f = ["X","G","C","H"]
    v = F.(f)(:);
    if numel(v) ~= mE, error('Base.%s has %d elements, expected %d.', f, numel(v), mE); end
    F.(f) = v;
end
end

function [eid, sgn] = edge_index_sign(u,v,E)
if u < v, [~,eid] = ismember([u v], E, 'rows'); sgn = +1;
else,     [~,eid] = ismember([v u], E, 'rows'); sgn = -1;
end
if isempty(eid) || eid==0, eid = 0; sgn = 0; end
end

function [CX, CY, Umap, Vmap] = edgeflow_to_facevec(P,T,E,flowVec)
% Project edge-aligned scalar flow onto per-face average tangent vector.
nF = size(T,1);
tmp = reshape(P(T,:).', 2, 3, nF);
CX = squeeze(mean(tmp(1, :, :), 2));
CY = squeeze(mean(tmp(2, :, :), 2));
Umap = zeros(nF,1); Vmap = zeros(nF,1);
for f = 1:nF
    v = T(f,:); segs = [v(1) v(2); v(2) v(3); v(3) v(1)]; % CCW
    for s = 1:3
        a = segs(s,1); b = segs(s,2);
        t = P(b,:) - P(a,:); Lt = norm(t); if Lt<1e-12, continue; end
        t_hat = t / Lt;
        [eid, sgn] = edge_index_sign(a,b,E);
        if eid==0, continue; end
        val = sgn * flowVec(eid);
        Umap(f) = Umap(f) + val * t_hat(1);
        Vmap(f) = Vmap(f) + val * t_hat(2);
    end
    Umap(f) = Umap(f)/3; Vmap(f) = Vmap(f)/3;
end
end

function quiver_faces_black(ax, CX, CY, U, V)
L = hypot(U,V); U = U./max(L,eps); V = V./max(L,eps);
quiver(ax, CX, CY, U, V, 0.9, 'Color',[0 0 0], 'LineWidth',1.0, 'MaxHeadSize',0.7);
end

function [Xg, Yg, Ug, Vg] = facevec_to_grid_rect(CX,CY,U,V,ngrid, bbox)
% Rectangular gridding over bbox with 'natural' + 'nearest' extrapolation (fills rectangle).
if nargin < 6 || isempty(bbox)
    xmin = min(CX); xmax = max(CX); ymin = min(CY); ymax = max(CY);
else
    xmin = bbox(1); xmax = bbox(2); ymin = bbox(3); ymax = bbox(4);
end
xv = linspace(xmin, xmax, ngrid);
yv = linspace(ymin, ymax, ngrid);
[Xg,Yg] = meshgrid(xv,yv);
Fu = scatteredInterpolant(CX, CY, U, 'natural', 'nearest');
Fv = scatteredInterpolant(CX, CY, V, 'natural', 'nearest');
Ug = Fu(Xg,Yg); Vg = Fv(Xg,Yg);
end

function scatter_colorbar(ax, X, Y, S, cmap, labelstr)
colormap(ax, cmap);
sminmax = robust_clim(S);
if ~all(isfinite(sminmax)) || sminmax(2)<=sminmax(1), sminmax=[0 1]; end
caxis(ax, sminmax);
scatter(ax, X, Y, 25, S, 'filled', 'MarkerEdgeColor','k');
cb = colorbar(ax); cb.Label.String = labelstr; cb.TickDirection = 'out'; cb.FontSize = 18;
end

function streams_color_by_scalar_ax(ax, Xg,Yg, U,V, S, step, lw, cmap, label, clim12)
% Uses unique 1-D grids to avoid "Sample points must be unique" and colors paths by S.
colormap(ax, cmap);
if nargin>=11 && ~isempty(clim12), clim = clim12; else, clim = robust_clim(S); end
if ~isfinite(clim(1)) || ~isfinite(clim(2)) || clim(2)<=clim(1), clim=[0 1]; end
caxis(ax, clim);

xv = Xg(1,:); yv = Yg(:,1);
[xv, ix] = unique(xv, 'stable');
[yv, iy] = unique(yv, 'stable');
if numel(xv) < 2 || numel(yv) < 2
    imagesc(ax, Xg(1,:), Yg(:,1), S); set(ax,'YDir','normal');
    cb = colorbar(ax); cb.Label.String = label; cb.TickDirection = 'out'; cb.FontSize = 18;
    return;
end
Uu = U(iy,ix); Vu = V(iy,ix); Su = S(iy,ix);
Un = Uu; Vn = Vu; Un(~isfinite(Un))=0; Vn(~isfinite(Vn))=0;

h = streamslice(ax, xv, yv, Un, Vn, step);

if ~isempty(h)
    nx = numel(xv); ny = numel(yv);
    x0 = xv(1); x1 = xv(end); y0 = yv(1); y1 = yv(end);
    for k = 1:numel(h)
        xd = get(h(k),'XData'); yd = get(h(k),'YData');
        if isempty(xd) || isempty(yd), continue; end
        ixq = round( (xd - x0) ./ max(eps,(x1-x0)) * (nx-1) + 1 );
        iyq = round( (yd - y0) ./ max(eps,(y1-y0)) * (ny-1) + 1 );
        ixq = max(1,min(nx,ixq)); iyq = max(1,min(ny,iyq));
        seg = Su(sub2ind(size(Su), iyq, ixq)); seg = seg(isfinite(seg));
        if isempty(seg), sm = mean(Su(isfinite(Su)),'all'); if isempty(sm), sm = mean(clim); end
        else, sm = mean(seg); end
        t = (sm - clim(1))/max(eps,clim(2)-clim(1)); t = max(0,min(1,t));
        cidx = 1 + round(t*(size(cmap,1)-1)); cidx = max(1,min(size(cmap,1),cidx));
        set(h(k),'Color',cmap(cidx,:), 'LineWidth', lw);
    end
end
cb = colorbar(ax); cb.Label.String = label; cb.TickDirection = 'out'; cb.FontSize = 18;
end

function clim = robust_clim(A)
vals = A(isfinite(A)); if isempty(vals), clim=[0 1]; return; end
p = prctile(vals,[2 98]); if p(2)<=p(1), p=[min(vals) max(vals)]; end
if p(2)<=p(1), p=[0 1]; end
clim = p;
end

function C = single_hue_map(lightRGB, darkRGB, n)
t = linspace(0,1,n)'; 
C = (1-t).*lightRGB + t.*darkRGB;
end

function draw_quiver_black(ax, Xg,Yg, U,V)
M = isfinite(U) & isfinite(V); if ~any(M(:)), return; end
k = 2;
Xs = Xg(1:k:end,1:k:end); Ys = Yg(1:k:end,1:k:end);
Us = U(1:k:end,1:k:end);   Vs = V(1:k:end,1:k:end);
Ms = isfinite(Us) & isfinite(Vs);
L = hypot(Us,Vs); Us(Ms)=Us(Ms)./max(L(Ms),eps); Vs(Ms)=Vs(Ms)./max(L(Ms),eps);
quiver(ax, Xs(Ms), Ys(Ms), Us(Ms), Vs(Ms), 'AutoScale','on', ...
       'AutoScaleFactor',0.9, 'Color',[0 0 0], 'LineWidth',2.0, 'MaxHeadSize',1);
end

