function meanG = hodge_mean(varargin)
% HODGE_MEAN  Group-pooled mean for Hodge components.
%   meanG = hodge_mean(A)
%   meanG = hodge_mean(A, B)
%   meanG = hodge_mean(A, B, C, ...)
%
% Inputs (one or more):
%   Each argument may be:
%     - a numeric matrix (mE x nSub), interpreted as X only, or
%     - a struct with any subset of fields {X,G,C,H}, each mE x nSub (or mE x 1).
%
% Output:
%   meanG : struct whose fields are the components present in *all* inputs
%           (subset of {X,G,C,H}). Each field is an mE x 1 vector equal to
%           the unweighted average of the per-group means:
%               meanG.K = (1/Ng) * sum_g mean(group_g.K, 2, 'omitnan')
%
% Notes:
%   - NaNs are ignored within each group's mean (nanmean).
%   - All groups used for a component must have the *same* number of edges mE.
%   - With a single input, this simply returns nanmean along subjects.
%
% (C) 2025 Moo K. Chung 
% mkchung@wisc.edu
% University of Wisconsin-Madison


% Normalize all inputs to structs with possible fields {X,G,C,H}
G = cellfun(@normalize_input_, varargin, 'UniformOutput', false);

% Components present in ALL inputs, in canonical order
order = {'X','G','C','H'};
common = order;
for i = 1:numel(G)
    common = intersect(common, fieldnames(G{i})');
end


% Build pooled (unweighted) mean across groups
meanG = struct();
for k = 1:numel(common)
    f = common{k};

    % Check consistent mE across groups for this component
    mE = size(G{1}.(f), 1);
    for i = 2:numel(G)
        if size(G{i}.(f), 1) ~= mE
            error('Component %s has mismatched mE: group 1 = %d, group %d = %d.', ...
                f, mE, i, size(G{i}.(f),1));
        end
    end

    % Per-group means (ignoring NaNs), then unweighted average across groups
    mu = zeros(mE, numel(G));
    for i = 1:numel(G)
        mu(:,i) = nanmean(G{i}.(f), 2);
    end
    meanG.(f) = mean(mu, 2, 'omitnan');
end
end

% -------- helper --------
function S = normalize_input_(X)
if isnumeric(X)
    S = struct('X', X);
elseif isstruct(X)
    S = struct();
    for ff = {'X','G','C','H'}
        f = ff{1};
        if isfield(X, f) && ~isempty(X.(f))
            S.(f) = X.(f);
        end
    end

end