function planner_complex_display(S)
% PLANNER_COMPLEX_DISPLAY  Publication-quality visualization of a 2D 
% simplicial complex with oriented edges. 
% 
% Inputs: 
%   S.P: vertex coordinates
%   S.E: undirected edge list (each row [u v] with u<v as reference orientation).
%   S.T: face indices T (CCW),
%
% Usage:
%   planner_complex_display(P, T, Euniq)
%
% (C) 2025 Moo K. Chung 
% mkchung@wisc.edu
% University of Wisconsin-Madison

P=S.P;
Euniq=S.E;
T= S.T;

% ---- figure/axes (clean, consistent margins) ----
fig = figure('Color','w','Units','pixels','Position',[120 120 900 700]);
ax  = axes('Parent',fig); hold(ax,'on'); axis(ax,'equal'); axis(ax,'off');
ax.Position = [0.02 0.02 0.96 0.96];  % tight layout

% ---- aesthetic parameters (publication-ready) ----
faceColor  = [0.92 0.92 0.92];
faceAlpha  = 0.85;
edgeColor  = [0.05 0.05 0.05];
edgeWidth  = 1.25;
arrowColor = [0.3 0.3 0.3];
arrowWidth = 1.6;
arrowScale = 0.28;   % length fraction along each edge
headSize   = 1.5;   % quiver head size
endShrink  = 0.10;   % shrink from endpoints to keep arrows off vertices
nodeColor  = [0 0 0];
nodeSize   = 10;

% ---- draw faces (subtle fill, no face edges) ----
if ~isempty(T)
    patch('Faces',T,'Vertices',P, ...
          'FaceColor',faceColor,'FaceAlpha',faceAlpha, ...
          'EdgeColor','none','Parent',ax);
end

% ---- draw undirected edge lines (uniform black) ----
if ~isempty(Euniq)
    X = [P(Euniq(:,1),1), P(Euniq(:,2),1)]';
    Y = [P(Euniq(:,1),2), P(Euniq(:,2),2)]';
    plot(ax, X, Y, '-', 'Color', edgeColor, 'LineWidth', edgeWidth);
end

% ---- draw oriented arrows along edges (reference orientation u->v with u<v) ----
mE = size(Euniq,1);
for e = 1:mE
    u = Euniq(e,1); v = Euniq(e,2);
    a = P(u,:);     b = P(v,:);
    d = b - a;      L = norm(d);
    if L < 1e-12, continue; end
    dir = d / L;

    % start a bit away from tail; draw a fixed fraction of the edge
    p0   = a + endShrink*L*dir;
    len  = (1 - 2*endShrink) * arrowScale * L;
    vec  = len * dir;

    quiver(ax, p0(1), p0(2), vec(1), vec(2), 0, ...
        'Color', arrowColor, 'LineWidth', arrowWidth, ...
        'MaxHeadSize', headSize, 'AutoScale','off');
end

% ---- draw vertices (small black points) ----
plot(ax, P(:,1), P(:,2), '.', 'Color', nodeColor, 'MarkerSize', nodeSize);

% ---- frame & padding for clean export ----
xlim(ax, [min(P(:,1)) max(P(:,1))] + 0.03*[-1 1]*(range(P(:,1))+eps));
ylim(ax, [min(P(:,2)) max(P(:,2))] + 0.03*[-1 1]*(range(P(:,2))+eps));
set(ax,'Clipping','off');

end