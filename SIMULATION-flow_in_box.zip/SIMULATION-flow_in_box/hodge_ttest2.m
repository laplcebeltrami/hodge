function stats = hodge_ttest2(A, B)
% HODGE_TEST  Edge-wise two-sample tests (equal variances) for X,G,C,H.
%   stats = hodge_test(A, B)
%
% Inputs:
%   A, B : either
%       (i) numeric matrices (mE x nSub) -> interpreted as X only, or
%      (ii) structs with any subset of fields {X,G,C,H}, each mE x nSub.
% For instance,
% A =
% struct with fields:
% 
% G: [210×40 double]
% C: [210×40 double]
% H: [210×40 double]
% X: [210×40 double]
%
% where 210 is # of edges and 40 is # of subjects. B is similarly structued. 
%
%
% Output:
%   stats.edge.<comp>.p : [mE x 1] per-edge two-sided p-values for each
%                         component present in BOTH A and B (comp ∈ {X,G,C,H}).
%
% Notes:
%   - Uses MATLAB ttest2 with 'Vartype','equal' at each edge (row).
%   - NaNs are ignored by ttest2 per edge; if an edge lacks data in a group
%     the returned p-value for that edge is NaN.
%
%
% (C) 2025 Moo K. Chung 
% mkchung@wisc.edu
% University of Wisconsin-Madison



comps = {'X','G','C','H'};

for k = 1:numel(comps)
    f = comps{k};
    Amat = double(A.(f));   % [mE x nA]
    Bmat = double(B.(f));   % [mE x nB]

    % ttest2 operates along columns -> transpose so each edge is a column
    % Equal variances, two-sided
    % transpose so ttest2 runs per-edge
    [H,P,CI,STATS] = ttest2(Amat', Bmat', 'Vartype','equal', 'Tail','both');
    stats.(f) = STATS.tstat';  % directly store as vector of doubles
end




