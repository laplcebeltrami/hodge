%% SIMULATION: Two-sample test on Hodge-components
%% flows in a square consisting of connected 2D simplicial complex
% Clear, visible group differences in Hodge components (G/C/H),
% but NO visible / statistical local differences in the TOTAL edge flow X.
%
% (C) 2025 Moo K. Chung
% Univeristy of Wisconsin-Madison
%
% If you are using the part of codes or functions, reference 
% Anand, D. V., & Chung, M. K. (2024, May). Hodge-decomposition of brain 
% networks. In 2024 IEEE International Symposium on Biomedical Imaging (ISBI) 
% (pp. 1-5)
%
% @inproceedings{anand2024hodge,
%   title={Hodge-decomposition of brain networks},
%   author={Anand, D.V. and Chung, M.K.},
%   booktitle={2024 IEEE International Symposium on Biomedical Imaging (ISBI)},
%   pages={1--5},
%   year={2024},
%   organization={IEEE}
% }

%
%% Build planar complex with holes + partial triangle fill
% Partial triangle fill controls the ratio of curl vs. harmonic flows. 

nPtsPerDim = 10; % # of points per side. There will be 100 points in the square.
fillFrac = 0.5; % Keep only a fraction of faces to get nontrivial curl/harmonic

S = planar_complex(nPtsPerDim, fillFrac);
% S = 
%   struct with fields:
%     P: [97×2 double]  %0-simplex: nodes
%     E: [210×2 double] %1-simplex: directed edges (indexing follows i<j convention)
%     T: [94×3 double]  %2-simplex: triangles

% Save all the topolgoical information
summary = planar_complex_summary(S);
summary.counts
summary.topology

planner_complex_display(S);

%% Group level Hodge decompostion on 2D simplical complex
X = planar_complex_hodge_baselines(S);
% It outputs Hodge decompostion as
% X = 
%   struct with fields:
%     G: [210×1 double]
%     C: [210×1 double]
%     H: [210×1 double]
%     X: [210×1 double]

% Dispays hodge components
hodge_display(S, X, 20);

%Spilitting into Two cannonical flows for two groups
%Simply randomly adding noise into each component does not make it a
%valid Hodge component. 

A = X.G + X.C - 0.1*X.H; %Group A
B = X.G + X.C + 0.1*X.H; %Group B
%A and B have identical gradient and curl but composite direction of
%harmonic flows. 

Anew = hodge_decomposition(S, A);
hodge_display(S, Anew, 20);

Bnew = hodge_decomposition(S, B);
hodge_display(S, Bnew, 20);

%% Subject-level Hodge decompostion 
nA = 30; nB = 30; % # of subject in each group
sigma = 0.01; % noise variability

Agroup = hodge_simulate_subject(Anew, sigma, nA);
% Agroup consists of nA number of Hodge decomposition
%   struct with fields:
%     G: [210×30 double]
%     C: [210×30 double]
%     H: [210×30 double]
%     X: [210×30 double]
meanA = hodge_mean(Agroup); %Averge of hodge decomposition.
hodge_display(S, meanA, 20); 

Bgroup = hodge_simulate_subject(Bnew, sigma, nB);
meanB = hodge_mean(Bgroup);
hodge_display(S, meanB, 20);

%% Statistical Analysis - Local & Global
stats = hodge_ttest2(Agroup, Bgroup);

alpha =0.05
S = hodge_stats_summary(stats, nA, nB, alpha)

meanAB = hodge_mean(Agroup,Bgroup);
diffAB = hodge_difference(Agroup,Bgroup)

out = hodge_stat_display(S, meanAB,  stats, 20, 5, [-5 5])
out = hodge_stat_display(S, diffAB ,  stats, 20, 5, [-5 5])

