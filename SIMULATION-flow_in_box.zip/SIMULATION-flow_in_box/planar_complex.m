function S = planar_complex(nPtsPerDim, fillFrac)
% PLANAR_COMPLEX  Build a 2D simplicial complex from a perturbed grid 
%                 on [0,1]^2 and keep a fraction of faces (no holes).
%
% Inputs
%   nPtsPerDim : integer, number of grid points per dimension (N x N grid)
%   fillFrac   : scalar in (0,1], fraction of faces to keep
%
% Outputs
%   S.P     : [nV x 2] vertex coordinates (only vertices used by T)
%   S.E     : [mE x 2] unique undirected edges (u < v) built from T
%   S.T     : [nF x 3] triangle indices (faces), oriented CCW
%
% (C) 2025 Moo K. Chung 
% mkchung@wisc.edu
% University of Wisconsin-Madison
%

rng(1)                     % reproducible (optional)
bounds  = [0 1; 0 1];      % unit square
epsPert = 0.1;            % tiny perturbation to avoid degeneracy

% ---- build (perturbed) regular grid in bounds ----
[xg, yg] = meshgrid(linspace(bounds(1,1), bounds(1,2), nPtsPerDim), ...
                    linspace(bounds(2,1), bounds(2,2), nPtsPerDim));
P = [xg(:), yg(:)];
if epsPert > 0
    P = P + epsPert*randn(size(P));
end

% ---- Delaunay triangulation ----
DT   = delaunayTriangulation(P);
Tall = DT.ConnectivityList;

% ---- keep only a fraction of faces (no holes) ----
fillFrac = max(0,min(1,fillFrac));                     % clamp
nKeep    = max(1, round(fillFrac * size(Tall,1)));
idx      = randperm(size(Tall,1), nKeep);
T        = sortrows(Tall(idx,:));                      % deterministic order

% ---- orient faces CCW ----
P1 = P(T(:,1),:); P2 = P(T(:,2),:); P3 = P(T(:,3),:);
area2 = (P2(:,1)-P1(:,1)).*(P3(:,2)-P1(:,2)) - (P2(:,2)-P1(:,2)).*(P3(:,1)-P1(:,1));
flip = area2 < 0;  T(flip,[2 3]) = T(flip,[3 2]);

% ---- prune unused vertices and reindex T ----
usedV = unique(T(:));
P = P(usedV, :);
newIdx = zeros(max(usedV),1); newIdx(usedV) = 1:numel(usedV);
T = newIdx(T);

% ---- unique undirected edges (u < v) from reindexed T ----
Eall  = sort([T(:,[1 2]); T(:,[2 3]); T(:,[3 1])], 2);
Euniq = unique(Eall, 'rows');

S.P = P;
S.E = Euniq;
S.T = T;

end

