function summary = hodge_ttest2_summary(stats, n1, n2, alpha)
% HODGE_TTEST2_SUMMARY  Per-component statistial summary of edge-wise 
% two-sample t-stats.
%
% Inputs
%   stats : struct with fields .X .G .C .H, each mE x 1 vector of signed t-stats
%   n1,n2 : sample sizes in the two groups (default 30,30)
%   alpha : false discovery rate (FDR) level (default 0.05)
%
% Output summary:
%   .df         : degrees of freedom (n1+n2-2)
%   .alpha      : FDR level
%   .components : struct per component with fields:
%       n, t_max, idx_t_max, p_at_t_max, t_min, idx_t_min, p_at_t_min,
%       n_sig (FDR-significant count), sig (logical mask), p (vector),
%       q (BH-adjusted p-values), crit_p (BH cutoff)
%   .summaryTbl : table of per-component counts and extremes
%
% Notes
%   - p-values are two-sided from t with df = n1+n2-2.
%   - FDR is applied per component across edges.
%
%
% (C) 2025 Moo K. Chung 
% mkchung@wisc.edu
% University of Wisconsin-Madison

comps = {'X','G','C','H'};
for k = 1:numel(comps)
    c = comps{k};
    stats.(c) = double(stats.(c)(:));
end


df = n1 + n2 - 2;

% ----- compute per-component p-values & BH-FDR -----
C = struct();
for k = 1:numel(comps)
    c = comps{k};
    t = stats.(c);
    p = 2 * tcdf(-abs(t), df);  % two-sided p-values
    [sig, q, crit_p] = fdr_bh_local(p, alpha);
    [tmax, idxmax] = max(t);
    [tmin, idxmin] = min(t);

    C.(c) = struct( ...
        'n',          numel(t), ...
        't_max',      tmax, ...
        'idx_t_max',  idxmax, ...
        'p_at_t_max', 2 * tcdf(-abs(tmax), df), ...
        't_min',      tmin, ...
        'idx_t_min',  idxmin, ...
        'p_at_t_min', 2 * tcdf(-abs(tmin), df), ...
        'p',          p, ...
        'q',          q, ...
        'sig',        sig, ...
        'crit_p',     crit_p, ...
        'n_sig',      sum(sig) );
end


compName = strings(4,1);
nEdges   = zeros(4,1);
tMax     = zeros(4,1);
pAtMax   = zeros(4,1);
tMin     = zeros(4,1);
pAtMin   = zeros(4,1);
nSig     = zeros(4,1);
for k = 1:4
    c = comps{k};
    compName(k) = c;
    nEdges(k)   = C.(c).n;
    tMax(k)     = C.(c).t_max;
    pAtMax(k)   = C.(c).p_at_t_max;
    tMin(k)     = C.(c).t_min;
    pAtMin(k)   = C.(c).p_at_t_min;
    nSig(k)     = C.(c).n_sig;
end
summaryTbl = table(compName, nEdges, tMax, pAtMax, tMin, pAtMin, nSig, ...
    'VariableNames', {'Component','nEdges','t_max','p_at_t_max','t_min','p_at_t_min','n_sig_FDR'});

% ----- journal-style summary text (fixed concatenation) -----
lines = strings(0,1);
lines(end+1) = string(sprintf('Group sizes: n1=%d, n2=%d (df=%d). Two-sided t-tests per edge.', n1, n2, df));
lines(end+1) = string(sprintf('FDR control: Benjamini–Hochberg per component (q \\le %.3g).', alpha));
for k = 1:numel(comps)
    c = comps{k};
    L = sprintf(['%s: n=%d edges; t-range [%.3f, %.3f]; ' ...
        'p at negative extreme = %.3g (t=%.3f @%d); ' ...
        'p at positive extreme = %.3g (t=%.3f @%d); ' ...
        'FDR-significant edges = %d.'], ...
        c, C.(c).n, C.(c).t_min, C.(c).t_max, ...
        C.(c).p_at_t_min, C.(c).t_min, C.(c).idx_t_min, ...
        C.(c).p_at_t_max, C.(c).t_max, C.(c).idx_t_max, ...
        C.(c).n_sig);
    lines(end+1) = string(L);
end

% ----- pack output -----
summary = struct();
summary.df         = df;
summary.alpha      = alpha;
summary.components = C;
summary.summaryTbl = summaryTbl;

end

% ------------------ helper ------------------
function [sig, q, crit_p] = fdr_bh_local(p, alpha)
% Standard BH procedure (non-negative dependent/independent).
p = p(:);
m = numel(p);
[ps, order] = sort(p);
ranks = (1:m)';

thresh = (ranks/m) * alpha;
below  = ps <= thresh;
if any(below)
    kmax = find(below, 1, 'last');
    crit_p = ps(kmax);
else
    kmax = 0;
    crit_p = 0;
end
sig_sorted = false(m,1);
if kmax > 0
    sig_sorted(1:kmax) = true;
end
sig = false(m,1);
sig(order) = sig_sorted;

% BH-adjusted q-values (Storey-type monotone correction)
q_sorted = (m ./ ranks) .* ps;
% enforce monotonicity from largest to smallest
for i = m-1:-1:1
    q_sorted(i) = min(q_sorted(i), q_sorted(i+1));
end
q = zeros(m,1);
q(order) = min(q_sorted, 1);
end