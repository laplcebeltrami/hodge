function Abase = planar_complex_hodge_baselines(S)
% PLANAR_COMPLEX_HODGE_BASELINES  Construct baseline Hodge components that
% are strictly in the Gradient, Curl, and Harmonic subspaces.
%
%   Abase = planar_complex_hodge_baselines(P, T, Euniq)
%
% Inputs
%   S.P      : nV x 2 vertex coordinates
%   S.E      : mE x 2 undirected edges with u < v (defines edge orientation)
%   S.T      : nF x 3 triangle indices (CCW)
%
% Output
%   Abase struct with fields (each mE x 1):
%     G : exact component in im(B1')
%     C : coexact component in im(B2)
%     H : harmonic component in ker(B1) ∩ ker(B2')
%     X : total = G + C + H
%
% Notes
%   - All components are L2-unitized for comparability.
%   - H is obtained by projecting a structured seed onto the true harmonic
%     subspace; if the domain has no harmonic dof (b1 = 0), H = 0.
%
% (C) 2025 Moo K. Chung 
% mkchung@wisc.edu
% University of Wisconsin-Madison

P=S.P;
Euniq=S.E;
T= S.T;


% ---------- Build incidences ----------
[nV,~] = size(P); mE = size(Euniq,1); nF = size(T,1);

% B1: node-edge incidence (u->v for u<v)
tails = Euniq(:,1); heads = Euniq(:,2);
B1 = sparse(nV,mE);
B1 = B1 + sparse(tails,(1:mE)',-1,nV,mE) + sparse(heads,(1:mE)',+1,nV,mE);

% B2: edge-face incidence consistent with CCW triangles
B2 = sparse(mE,nF);
for f = 1:nF
    v1 = T(f,1); v2 = T(f,2); v3 = T(f,3);
    [e12,s12] = edge_index_sign(v1,v2,Euniq);
    [e23,s23] = edge_index_sign(v2,v3,Euniq);
    [e31,s31] = edge_index_sign(v3,v1,Euniq);
    if e12>0, B2(e12,f) = B2(e12,f) + s12; end
    if e23>0, B2(e23,f) = B2(e23,f) + s23; end
    if e31>0, B2(e31,f) = B2(e31,f) + s31; end
end

% Orthogonal projectors onto im(B1') and im(B2)
PG = B1' * pinv(full(B1*B1')) * B1;
PC = B2  * pinv(full(B2'*B2)) * B2';
PH = speye(mE) - PG - PC;  % projector onto harmonic subspace H

% Convenience normalizer
unitize = @(x) (norm(x) > 0) .* (x / max(norm(x), eps));

% ---------- GRADIENT baseline: phi(x,y) = x - y ----------
phi = P(:,1) - P(:,2);
G0  = B1' * phi;  % along-edge differences following Euniq orientation
G   = PG * G0;    % ensure pure exact
G   = unitize(G);

% ---------- CURL baseline: face potential psi ≡ 1 ----------
psi = ones(nF,1);
C0  = B2 * psi;
C   = PC * C0;    % ensure pure coexact
C   = unitize(C);

% ---------- HARMONIC baseline: project a structured seed onto H ----------
% Build an orthonormal basis for H = ker(B1) ∩ ker(B2')
M = [B1; B2'];                 % (nV + nF) x mE
% Use SVD-based null space with an automatic tolerance
Hbasis = null(full(M));        % mE x k (k = dim harmonic space)
if isempty(Hbasis)
    H = zeros(mE,1);
else
    % Seed: CCW tangential field about bbox center, sampled at edge midpoints
    ctr = 0.5*(max(P,[],1) + min(P,[],1));   % robust center of domain
    R   = [0 -1; 1 0];                       % 90° CCW
    d    = P(Euniq(:,2),:) - P(Euniq(:,1),:);
    L    = sqrt(sum(d.^2,2));
    ehat = d ./ max(L, eps);                 % unit edge directions
    mpt  = 0.5*(P(Euniq(:,1),:) + P(Euniq(:,2),:));
    rvec = mpt - ctr; rn = sqrt(sum(rvec.^2,2));
    t_ccw = (rvec*R.')./max(rn,1e-14);       % CCW tangents
    seed  = sum(t_ccw .* ehat, 2);           % scalar along each edge

    % Project seed into H (this equals PH*seed but via an explicit basis)
    H = Hbasis * (Hbasis' * seed);

    % If projection is numerically tiny (seed ~ orthogonal), fall back to a basis column
    if norm(H) < 1e-12
        H = Hbasis(:,1);
    end
    H = unitize(H);
end

% ---------- Pack result ----------
Abase = struct('G', G, 'C', C, 'H', H, 'X', (G + C + H));
end

% ===================== helpers =====================

function [eid, sgn] = edge_index_sign(u,v,E)
% Return index eid for the undirected edge {u,v} in E (with u<v in E),
% and sgn = +1 if orientation in E is u->v, sgn = -1 if E stores v->u.
if u < v
    [tf,eid] = ismember([u v], E, 'rows'); sgn = +1;
else
    [tf,eid] = ismember([v u], E, 'rows'); sgn = -1;
end
if ~tf, eid = 0; sgn = 0; end
end

