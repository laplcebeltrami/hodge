function A = hodge_simulate_subject(Abase, sigma, nA)
% HODGE_SIMULATE_SUBJECT  Generate nA subjects by adding independent edge noise.
%
% Inputs
%   Abase : struct with fields .G, .C, .H  (each mE x 1)
%   sigma : scalar standard deviation of Gaussian noise (e.g. 0.1)
%   nA    : integer number of subjects to generate
%
% Output
%   A : struct with fields .G, .C, .H, .X  (each mE x nA)
%
% Notes
%   - Noise is added independently to each edge of each component:
%       G_i = G0 + N(0, sigma^2 I),
%       C_i = C0 + N(0, sigma^2 I),
%       H_i = H0 + N(0, sigma^2 I).
%
% (C) 2025 Moo K. Chung 
% mkchung@wisc.edu
% University of Wisconsin-Madison


% ---- validate baseline ----
req = {'G','C','H'};

G0 = Abase.G(:);
C0 = Abase.C(:);
H0 = Abase.H(:);

mE = numel(G0);


for k = 1:numel(req)


    % ---- allocate ----
    A.G = zeros(mE, nA);
    A.C = zeros(mE, nA);
    A.H = zeros(mE, nA);
    A.X = zeros(mE, nA);

    % ---- generate subjects ----
    for i = 1:nA
        g = G0 + sigma * normrnd(0,1,mE,1);
        c = C0 + sigma * normrnd(0,1,mE,1);
        h = H0 + sigma * normrnd(0,1,mE,1);
        A.G(:,i) = g;
        A.C(:,i) = c;
        A.H(:,i) = h;
        A.X(:,i) = g + c + h;
    end
end