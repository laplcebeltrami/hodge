function summary = planar_complex_summary(S)
% PLANAR_COMPLEX_SUMMARY  Print & return a summary of a 2D simplicial complex.
%   S = planar_complex_summary(P, Euniq, T)
%
% Inputs
%   S.P      : [nV x 2] vertex coordinates
%   S.E      : [mE x 2] unique undirected edges (each row u<v)
%   S.T      : [nF x 3] triangle indices (assumed CCW)
%
% Output struct S with fields:
%   .counts     : nV, mE, nF
%   .topology   : chi, b0, b1 (≈dim harmonic), rB1, rB2, nBoundaryEdges,
%                 nInteriorEdges, nBoundaryLoops
%   .geometry   : bbox, edgeLen stats, faceArea stats, vertexDegree stats
%   .orientation: nCCW
%
% Notes
%   - b1 is computed from Hodge ranks: b1 = mE - rank(B1) - rank(B2).
%   - Boundary edges are those that appear exactly once across triangle faces.
%
% (C) 2025 Moo K. Chung 
% mkchung@wisc.edu
% University of Wisconsin-Madison

P=S.P;
Euniq=S.E;
T= S.T;

% ---------- sizes ----------
nV = size(P,1);
mE = size(Euniq,1);
nF = size(T,1);

% ---------- build B1 (node-edge incidence, u->v with u<v) ----------
tails = Euniq(:,1); heads = Euniq(:,2);
B1 = sparse(nV, mE);
B1 = B1 + sparse(tails, (1:mE)', -1, nV, mE) ...
         + sparse(heads, (1:mE)', +1, nV, mE);

% ---------- build B2 (edge-face incidence, consistent with CCW T) ----------
B2 = sparse(mE, nF);
for f = 1:nF
    v1 = T(f,1); v2 = T(f,2); v3 = T(f,3);
    [e12,s12] = edge_index_sign(v1, v2, Euniq);
    [e23,s23] = edge_index_sign(v2, v3, Euniq);
    [e31,s31] = edge_index_sign(v3, v1, Euniq);
    if e12>0, B2(e12,f) = B2(e12,f) + s12; end
    if e23>0, B2(e23,f) = B2(e23,f) + s23; end
    if e31>0, B2(e31,f) = B2(e31,f) + s31; end
end

% ---------- ranks, Euler characteristic, Betti-1 ----------
rB1 = rank(full(B1));
rB2 = rank(full(B2));
chi = nV - mE - (-nF);          % == nV - mE + nF
b1  = mE - rB1 - rB2;           % dimension of harmonic subspace on edges (Hodge)

% ---------- connected components (b0) ----------
b0 = num_components(nV, Euniq);

% ---------- boundary edges & loops ----------
% Count how many times each (undirected) edge appears in the face list
Eall = sort([T(:,[1 2]); T(:,[2 3]); T(:,[3 1])], 2);
[~, ~, ic] = unique(Eall, 'rows');
edgeUseCount = accumarray(ic, 1, [mE 1]);  % aligned with Euniq if Euniq==unique(Eall)
% If triangulation was pruned/reshuffled, align via ismember
[EuniqFromFaces, ~, ic2] = unique(Eall, 'rows');
if size(EuniqFromFaces,1) ~= mE || any(any(EuniqFromFaces ~= Euniq))
    % re-accumulate into Euniq indexing
    edgeUseCount = zeros(mE,1);
    [~, loc] = ismember(Eall, Euniq, 'rows');
    for k = 1:numel(loc), edgeUseCount(loc(k)) = edgeUseCount(loc(k)) + 1; end
end
nBoundaryEdges = sum(edgeUseCount == 1);
nInteriorEdges = sum(edgeUseCount >= 2);

Ebd = Euniq(edgeUseCount == 1, :);
nBoundaryLoops = boundary_loops_count(nV, Ebd);

% ---------- geometry stats ----------
% Edge lengths
EL = vecnorm(P(Euniq(:,2),:) - P(Euniq(:,1),:), 2, 2);
edgeLen = stats1d(EL);

% Face areas (absolute, using cross in 2D)
P1 = P(T(:,1),:); P2 = P(T(:,2),:); P3 = P(T(:,3),:);
area2 = (P2(:,1)-P1(:,1)).*(P3(:,2)-P1(:,2)) - (P2(:,2)-P1(:,2)).*(P3(:,1)-P1(:,1));
FA = abs(area2)/2;
faceArea = stats1d(FA);

% Vertex degrees
deg = accumarray([Euniq(:);], 1, [nV 1]); % each edge contributes to two vertices
vertexDegree = stats1d(deg);

% Orientation check
nCCW = sum(area2 > 0);

% Bounding box
bbox = [min(P(:,1)), max(P(:,1)); min(P(:,2)), max(P(:,2))];

% ---------- pack & print ----------
summary = struct();
summary.counts     = struct('nV',nV,'mE',mE,'nF',nF);
summary.topology   = struct('chi',chi,'b0',b0,'b1',b1,'rB1',rB1,'rB2',rB2, ...
                      'nBoundaryEdges',nBoundaryEdges,'nInteriorEdges',nInteriorEdges, ...
                      'nBoundaryLoops',nBoundaryLoops);
summary.geometry   = struct('bbox',bbox,'edgeLen',edgeLen,'faceArea',faceArea,'vertexDegree',vertexDegree);
summary.orientation= struct('nCCW',nCCW);

end

% ===== helpers =====
function [eid, sgn] = edge_index_sign(u,v,E)
if u < v, [~,eid] = ismember([u v], E, 'rows'); sgn = +1;
else,     [~,eid] = ismember([v u], E, 'rows'); sgn = -1;
end
if isempty(eid) || eid==0, eid = 0; sgn = 0; end
end

function k = num_components(nV, E)
try
    G  = graph(E(:,1), E(:,2), [], nV);
    cc = conncomp(G);
    k  = max(cc);
catch
    % fallback: simple BFS/DFS
    adj = sparse([E(:,1);E(:,2)],[E(:,2);E(:,1)],1,nV,nV);
    seen = false(nV,1); k = 0;
    for s = 1:nV
        if ~seen(s)
            k = k+1;
            stack = s;
            seen(s) = true;
            while ~isempty(stack)
                u = stack(end); stack(end) = [];
                nbrs = find(adj(u,:));
                for v = nbrs
                    if ~seen(v), seen(v)=true; stack(end+1)=v; end %#ok<AGROW>
                end
            end
        end
    end
end
end

function nLoops = boundary_loops_count(nV, Ebd)
if isempty(Ebd)
    nLoops = 0; return;
end
try
    Gbd    = graph(Ebd(:,1), Ebd(:,2), [], nV);
    labels = conncomp(Gbd);
    comps  = unique(labels(nonzeros(labels)));
    nLoops = numel(comps);
catch
    % crude fallback: count components in boundary subgraph
    nLoops = num_components(nV, Ebd);
end
end

function st = stats1d(x)
x = x(:); x = x(isfinite(x));
if isempty(x), st = struct('min',NaN,'med',NaN,'mean',NaN,'max',NaN); return; end
st = struct('min',min(x), 'med',median(x), 'mean',mean(x), 'max',max(x));
end