function Xnew = hodge_decomposition(S, X)
% HODGE_DECOMPOSITION  Decompose an edge flow into Gradient, Curl, 
% Harmonic parts.
%
% Usage:
%   Xnew = hodge_decomposition(P, T, E, X)
%
% Inputs
%   P : (nV x 2) vertex coordinates
%   T : (nF x 3) faces, CCW vertex indices
%   E : (mE x 2) undirected edges with u < v (required)
%   X : edge flow, either a vector (mE x 1) or struct with field .X (mE x 1)
%
% Output
%   Xnew : struct with fields
%          .G (mE x 1)  gradient component
%          .C (mE x 1)  curl (solenoidal) component
%          .H (mE x 1)  harmonic component
%          .X (mE x 1)  original edge flow (copy of input)
%
% Notes
% - Projectors:
%     PG = B1' * pinv(B1*B1') * B1
%     PC = B2  * pinv(B2'*B2)  * B2'
%     PH = I - PG - PC
% - Assumes E lists each undirected edge once with u<v. If not, fix E first.
%
% (C) 2025 Moo K. Chung 
% mkchung@wisc.edu
% University of Wisconsin-Madison

P=S.P;
E=S.E;
T=S.T;

 
mE = size(E,1);
x = double(X(:));

%% build incidence matrices 
nV = size(P,1);
nF = size(T,1);

% B1: node-edge incidence (tail->head) given undirected E with u<v
tails = E(:,1); heads = E(:,2);
B1 = sparse(nV, mE);
B1 = B1 + sparse(tails, (1:mE)', -1, nV, mE) + sparse(heads, (1:mE)', +1, nV, mE);

% B2: edge-face incidence w.r.t. CCW T
B2 = sparse(mE, nF);
for f = 1:nF
    v1 = T(f,1); v2 = T(f,2); v3 = T(f,3);
    [e12,s12] = edge_index_sign(v1, v2, E);
    [e23,s23] = edge_index_sign(v2, v3, E);
    [e31,s31] = edge_index_sign(v3, v1, E);
    if e12>0, B2(e12,f) = B2(e12,f) + s12; end
    if e23>0, B2(e23,f) = B2(e23,f) + s23; end
    if e31>0, B2(e31,f) = B2(e31,f) + s31; end
end

%% projectors onto subspaces
% Use pseudoinverses to be robust on non-full-rank meshes
PG = B1' * pinv(full(B1*B1')) * B1;   % gradient (exact 1-form)
PC = B2  * pinv(full(B2'*B2)) * B2';  % curl     (coexact 1-form)
PH = speye(mE) - PG - PC;             % harmonic

% Hodge projections
G = PG * x;
C = PC * x;
H = PH * x;

% pack output 
Xnew = struct('G', G, 'C', C, 'H', H, 'X', x);
end

%% Helper functions

function [eid, sgn] = edge_index_sign(u, v, E)
% Return (eid, sgn) so that flow on directed segment u->v
% corresponds to sgn * x(eid), where eid is index into undirected E (u<v).
if u < v
    [tf, eid] = ismember([u v], E, 'rows'); sgn = +1;
else
    [tf, eid] = ismember([v u], E, 'rows'); sgn = -1;
end
if ~tf, eid = 0; sgn = 0; end
end