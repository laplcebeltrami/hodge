% SIMULATION study showing where harmonic flow excles in capturing
% recurrent cyclic interactions in a netework with 1-cycle while
% Granger casuality and structural equation struggle. 
%
%
% (c) 2025 Moo K. Chung
% University of Wisconsin-Madison

clear; clc; 

%% 1. Building Directed Cyclic Graph (DCG): 
%%    - a directed graph that contains one or more cycles
% Cycle-only ground truth (4-nodes 1-cycle) 
Nodes = [cos((0:3)'*2*pi/4) sin((0:3)'*2*pi/4)];  
Edges = [1 2; 2 3; 3 4; 4 1];
X     = [2; 3; 3; 2];   % edge flow strength, edges are indexed following 'Edges'.

% Add new nodes 
Nodes = [Nodes;
         0   1.8;  % node 5 above node 2
         0  0.2];  % node 6 below node 4
% Connect node 5 to node 2, and node 6 to node 4 
Edges = [Edges;
         2 5;      % edge from 2 -> 5
         6 4];     % edge from 6 -> 4
% Add edge flows 
% For each simulation one of below choice was used in the paper
%X = [X; 0.1; 0.1];   % strong circulation
X = [X; 5; 5];          % weak circualtion
figure;  graph_directed_plot(Nodes, Edges, X);

%% 2. Simulating random edge flow using vector autoregressive model
Z= VAR_graph(Edges, X, 4,1);
graph_directed_plot(Nodes, Edges, X);
graph_overlay_timeseries(Nodes, Z)

%-----------
%% 3. Ground truth connectivity matrix
% The ground truth is cycles. The goal is if we can detect 
% cyclic flow or not. 

X_truth = [2; 3; 3; 2; 0; 0]'; %ground truth edge flow
C_truth = graph_edge2matrix(Edges, X_truth);


%% 4. Comparision against Granger & SEM

% Trial settings
noise_levels = [0.1, 1, 10];
nTrials = 10; %10 trials for faster performance. 
              % change it to 100 for publication. 

% Collectors: rows = noise level, cols = trials
cos_hodge = nan(numel(noise_levels), nTrials); %Our method
cos_gc    = nan(numel(noise_levels), nTrials); %Granger
cos_sem   = nan(numel(noise_levels), nTrials); %SEM

for a = 1:numel(noise_levels)
    nl = noise_levels(a);

    for t = 1:nTrials
        % simulate VAR on this graph (use higher noise to hurt GC/SEM) 
        Z= VAR_graph(Edges, X, 10,nl);

        %% Harmonic flow from Hodge decomposition from time-lagged correlation (no triangles) 
        % build a time-lagged correlation matrix
        lag = 1;
        TL  = TS2timelagged(Z.', lag, size(Z.',1)-lag, 1);   % R x R x 1
        
        %make asymmetric matrix into antisymmetric
        TLas = adj_AntiSymmetric(TL); 
        
        % Create 1-Skeleton from the antisymmetric matrix. The simplical
        % complex will not have any curl. Only gradient and harmonic
        % compoents such that it contrast the peformance more.
        S= adj2simplex(TLas,1); % Note: S = Hodge_kSkeleton(TLas, 1) perform the identical task. 
        
        % Extract edge flow from antisymmetric matrix along 'Edges'.
        flows = adj2edgeflow(Edges, TLas);
        
        % Compute the boundary matrix
        B = PH_boundary(S);
        
        % Hodge decompostion
        [Yg, Yc, Yh] = Hodge_decompose_edgeflow(flows, B);

        % evaluate harmonic against ground truth
        H = flow2matrix(Nodes, Edges, Yh);
        scH = VAR_score(H, C_truth);   % performance score
        cos_hodge(a,t) = scH.cosine;
        
        %% Granger causality 
        [~, ~, GC_matrix, Pgc] = VAR_fit(Z);
        n = size(GC_matrix,1);
        Ghat = ones(n) - GC_matrix;
        Ghat(1:n+1:end) = 0;
        scG = VAR_score(Ghat, C_truth); % performance score
        cos_gc(a,t) = scG.cosine;
        
        %% Structural Equation Modeling (SEM)
        [B_est, X_pred, SEM_matrix] = SEM_fit(Z);
        Shat = ones(n) - SEM_matrix;
        Shat(1:n+1:end) = 0;
        scS = VAR_score(Shat, C_truth); % performance score
        cos_sem(a,t) = scS.cosine;
        
    end
end

%% 5. Performance table summarized as (mean ± std)

mH = mean(cos_hodge,2,'omitnan'); sH = std(cos_hodge,0,2,'omitnan');
mG = mean(cos_gc,   2,'omitnan'); sG = std(cos_gc,   0,2,'omitnan');
mS = mean(cos_sem,  2,'omitnan'); sS = std(cos_sem,  0,2,'omitnan');

fprintf('\n%-8s | %-22s | %-22s | %-22s\n', ...
    'Noise', 'Harmonic (mean ± std)', 'GC (mean ± std)', 'SEM (mean ± std)');
fprintf('%s\n', repmat('-', 1, 82)); % horizontal divider

for a = 1:numel(noise_levels)
    fprintf('%-8g | %.4f ± %.4f       | %.4f ± %.4f       | %.4f ± %.4f\n', ...
        noise_levels(a), ...
        mH(a), sH(a), ...
        mG(a), sG(a), ...
        mS(a), sS(a));
end

% You should get the following sample perfomance, which will change due to
% randomness of simulationed noise. 
%
% Strong circulation along 1-cycle
%Cosine similarity (mean ± std) over 100 trials:
%Noise = 0.1  | Harmonic: 0.9853 ± 0.0230 | GC: 0.8735 ± 0.0823 | SEM: 0.8770 ± 0.0913
%Noise = 1    | Harmonic: 0.9758 ± 0.0373 | GC: 0.8686 ± 0.0944 | SEM: 0.8606 ± 0.0865
%Noise = 10   | Harmonic: 0.9828 ± 0.0291 | GC: 0.8718 ± 0.0848 | SEM: 0.8782 ± 0.0810
%
% Weak circulation along 1-cycle
%Noise        | Hodge (mean ± std)        | GC (mean ± std)     | SEM (mean ± std)
%Noise = 0.1  | Harmonic: 0.9102 ± 0.0353 | GC: 0.8649 ± 0.0798 | SEM: 0.8705 ± 0.0980
%Noise = 1    | Harmonic: 0.9074 ± 0.0338 | GC: 0.8618 ± 0.0809 | SEM: 0.8619 ± 0.0935
%Noise = 10   | Harmonic: 0.8977 ± 0.0578 | GC: 0.8771 ± 0.0904 | SEM: 0.8720 ± 0.0997