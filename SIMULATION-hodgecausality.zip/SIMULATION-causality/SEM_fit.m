function [B_est, X_pred, SEM_matrix] = SEM_fit(X)
% SEM_FIT  Structural-equation–based contemporaneous causality (linear SEM).
% Fits Xi(t) = sum_{j!=i} B_ij Xj(t) + e_i(t) for each i by OLS on centered data,
% then returns coefficient matrix B_est, fitted series X_pred, and p-values per edge.
%
% Inputs:
%   X           : (N x T) multivariate time series (rows = variables, cols = time)
%
% Outputs:
%   B_est       : (N x N) SEM coefficient matrix with zeros on the diagonal
%                 (entry B_est(i,j) is the instantaneous effect j -> i)
%   X_pred      : (N x T) fitted values from the simultaneous linear SEM
%   SEM_matrix  : (N x N) two-sided p-values for H0: B_est(i,j) = 0 (j -> i), diag = NaN
%
% Notes:
%   - Each row i is obtained by regressing X_i on all other variables X_{-i} at the same time.
%   - Data are mean-centered per variable; no intercept is used. Predictions are re-centered.
%   - OLS is solved with backslash; standard errors use sigma^2 * pinv(Z'Z) to be robust to rank issues.
%   - This is a contemporaneous SEM (instantaneous effects), not a lagged VAR; direction relies on
%     asymmetric regression coefficients under the independent-errors SEM assumption.

    % ---- center data (no intercept in design) ----
    [N, T] = size(X);
    mu = mean(X, 2);
    Xc = X - mu .* ones(1, T);

    B_est      = zeros(N, N);
    SEM_matrix = NaN(N, N);
    X_pred_c   = zeros(N, T);

    for i = 1:N
        idx = [1:i-1, i+1:N];          % predictors (all except i)
        Z   = Xc(idx, :).';            % T x (N-1)
        y   = Xc(i, :).';              % T x 1

        % OLS coefficients and residuals
        beta = Z \ y;                  % (N-1) x 1
        e    = y - Z*beta;

        % Residual variance and coefficient covariance (pseudo-inverse for stability)
        df   = T - numel(idx);
        sigma2 = (e' * e) / max(df, 1);
        G      = Z' * Z;
        covb   = sigma2 * pinv(G);
        se     = sqrt(max(diag(covb), 0));   % guard against tiny negatives from numerics

        % Two-sided p-values for coefficients
        tstat = beta ./ max(se, eps);
        pvals = 2 * (1 - tcdf(abs(tstat), max(df, 1)));

        % Assemble row i of B and p-value matrix
        B_est(i, idx)       = beta.';
        SEM_matrix(i, idx)  = pvals.';

        % In-sample fitted values for Xi
        X_pred_c(i, :) = (beta.' * Xc(idx, :));
    end

    % Zero diagonal by construction; set SEM p-value diagonal to NaN
    B_est(1:N+1:end)      = 0;
    SEM_matrix(1:N+1:end) = NaN;

    % Re-center predictions
    X_pred = X_pred_c + mu .* ones(1, T);
end