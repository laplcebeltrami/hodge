function TLout = adj_AntiSymmetric(TL)
% adj_AntiSymmetric - Converts [R x R x N] directional matrices into antisymmetric form
% by retaining the dominant direction in each pairwise entry.
%
% INPUT:
%   TL     - [R x R x N] array of directional matrices
%
% OUTPUT:
%   TLout  - [R x R x N] antisymmetric matrices with TLout(i,j,w) = -TLout(j,i,w)
%
%
% (C) 2025 Moo K. Chung, 
%     University of Wisconsin-Madison
%
% Update histroy: 2024 August 12 created 
%                 2024 August 24 diagonal made into zero



[R, ~, N] = size(TL);
TLout = zeros(R, R, N);

for w = 1:N
    A = TL(:, :, w);           % Current matrix
    A_T = A';                  % Transpose for use in indexing
    keepIJ = A >= A_T;         % Logical mask for keeping A(i,j)

    B = zeros(R);
    B(keepIJ) = A(keepIJ);             % Assign dominant direction
    B(~keepIJ) = -A_T(~keepIJ);        % Assign opposite with negative sign

    %B(1:R+1:end) = diag(A);            % Preserve diagonal entries
    B(1:R+1:end) = 0; %make diagonal zero

    TLout(:, :, w) = B;
end

end


% function TLout = adj_AntiSymmetric(TL)
% % adj_AntiSymmetric - Converts a sequence of [R x R x N] directional matrices
% % into antisymmetric form by preserving the dominant edge
% %
% % INPUT:
% %   TL  - [R x R x N] array of asymmetric matrices
% %         TL(i,j,w) is the directional measure from i to j at window w
% %
% % OUTPUT:
% %   TLout - [R x R x N] array of antisymmetric matrices
% %           TLout(i,j,w) = -TLout(j,i,w); diagonal preserved
% %
% % (C) 2025 Moo K. Chung, University of Wisconsin-Madison
% 
% [R, ~, N] = size(TL);
% TLout = zeros(R, R, N);
% 
% for w = 1:N
%     A = TL(:, :, w);
%     B = A;
% 
%     for i = 1:R
%         for j = i+1:R
%             if A(i,j) >= A(j,i)
%                 B(j,i) = -A(i,j);
%             else
%                 B(i,j) = -A(j,i);
%             end
%         end
%     end
% 
%     TLout(:,:,w) = B;
% end
% end